/*
 * my_init_led.c
 *
 *  Created on: Oct 28, 2024
 *      Author: User
 */


#include "my_init_led.h"
void init_led(pin_t pin)
{
	 GPIO_InitTypeDef GPIO_InitStruct = {0};

	  /* GPIO Ports Clock Enable */
	 switch((uint32_t) pin.port)
	 {
	 case (uint32_t) GPIOA:
		  __HAL_RCC_GPIOA_CLK_ENABLE();
		  break;
	 case (uint32_t) GPIOB:
		  __HAL_RCC_GPIOA_CLK_ENABLE();
		  break;
	 }


	  /*Configure GPIO pin Output Level */
	  HAL_GPIO_WritePin(pin.port, 1<<pin.pin, GPIO_PIN_SET);


	  /*Configure GPIO pin : PtPin */
	  GPIO_InitStruct.Pin = 1<<pin.pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(pin.port, &GPIO_InitStruct);

	 }
