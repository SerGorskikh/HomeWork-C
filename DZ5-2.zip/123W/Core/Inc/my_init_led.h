/*
 * my_init_led.h
 *
 *  Created on: Oct 28, 2024
 *      Author: User
 */

#ifndef INC_MY_INIT_LED_H_
#define INC_MY_INIT_LED_H_


#include "stm32f4xx_hal.h"



typedef struct
{
	GPIO_TypeDef * port;
	char pin;
	}pin_t;
void init_led(pin_t pin);


#endif /* INC_MY_INIT_LED_H_ */
